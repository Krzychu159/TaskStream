export default function NotFoundPage() {
  return (
    <div className="text-xl m-auto w-max mt-16">
      Page not Found - check if your link is correct
    </div>
  );
}
