import { BoardScreen } from "@/features/board/screens/BoardScreen";

export default function BoardPage() {
  return <BoardScreen />;
}
