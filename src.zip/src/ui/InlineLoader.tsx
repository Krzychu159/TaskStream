export function InlineLoader() {
  return (
    <div className="h-4 w-4 border-2 border-gray-300 border-t-transparent rounded-full animate-spin" />
  );
}
